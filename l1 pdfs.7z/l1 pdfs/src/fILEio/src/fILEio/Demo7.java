package fILEio;

import java.io.File;
import java.io.IOException;

public class Demo7 {

	public static void main(String[] args) {
		
		File file= new File ("D:\\Training\\CoreJava\\FileHandling");
		File file1= new File(file.getPath()+"\\Demo.java");
		file.delete();//delete the FileHandling folder
		file1.delete(); // this will delete the Demo.java
		/*try {
		boolean res=	file1.createNewFile();
			if(res)
				System.out.println("file created");
			else
				System.out.println("file not created..");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		/*	
		boolean res=file.mkdir();
		if(res)
			System.out.println("directory created ");
		else 
			System.out.println("not created..");
	*/}
}
