package fILEio;

import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;

public class Demo6 {
	public static void main(String[] args) {
	File file= new File("FileDemo.txt");

		System.out.println(file.getPath());
		System.out.println(file.getAbsolutePath());
		long mod=file.lastModified();
		Date dt= new Date(mod);
		System.out.println("last modified : "+ dt);
	//	file.setReadOnly();
		file.setWritable(true);
	
	/*try {
			boolean res=file.createNewFile();
			if(res)
				System.out.println("file created ");
			else
				System.out.println("Error in creating file ");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
*/	
	}
}
