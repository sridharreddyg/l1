package fILEio;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Demo2 {

	public static void main(String[] args) {
		try {
			FileOutputStream fos= new FileOutputStream("basic.txt");
			DataOutputStream dos= new DataOutputStream(fos);
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter rollno ");
			int rollno= sc.nextInt();
			System.out.println("Enter name ");
			String name= sc.next();
			System.out.println("Enter Address ");
			String loc= sc.next();
			System.out.println("Enter Percent: ");
			double percent= sc.nextDouble();
					
			dos.writeInt(rollno);
			dos.writeUTF(name);
			dos.writeUTF(loc);
			dos.writeDouble(percent);
			System.out.println("Data written to file ....");			
			dos.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		

		
	}
}
