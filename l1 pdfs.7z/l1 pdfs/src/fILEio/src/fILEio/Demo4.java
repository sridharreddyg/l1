package fILEio;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Demo4 {
 
	public static void main(String[] args) {
	Student s=new Student();
	s.setRollno(35);
	s.setName("Aaradhya");
	s.setAddress("Pune");
	s.setPercent(57.75);
	try {
		FileOutputStream fos= new FileOutputStream("student.txt");
		ObjectOutputStream oos= new ObjectOutputStream(fos);
	    oos.writeObject(s);
		System.out.println("Student record written to file...");
		
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	
}
}
