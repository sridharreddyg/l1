package com.cg.enums;

public enum Month {

	Jan(31,"January"),Feb(28,"February"),Mar(31,"March"),
	Apr(30,"April"),May(31,"May"),Jun(30,"June"),Jul(31,"July"),
	Aug(31,"August"),Sep(30,"September"),Oct(31,"October"),Nov(30,"November")
	,Dec(31,"December");
	
	private int days;
	private String name;
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	private Month(int days, String name) {
		this.days = days;
		this.name = name;
	}
}
