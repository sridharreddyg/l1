import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class LoggerDemo {
	static Logger logger= Logger.getLogger(LoggerDemo.class);
	
	public static void main(String[] args) {
	PropertyConfigurator.configure("log4j.properties");
	
	logger.info("This is info level message");
	logger.debug("This is debug level message");
	logger.error("THis is error level message");
	logger.warn("This is warn level message");
	logger.fatal("this is fatal level message");
	
	System.out.println("messages logged to file : basic.log");
}
}
