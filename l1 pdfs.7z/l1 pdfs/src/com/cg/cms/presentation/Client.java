package com.cg.cms.presentation;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.cms.dto.Purchasedetails;
import com.cg.cms.exception.AdminException;
import com.cg.cms.service.AdminServiceImp1;
import com.cg.cms.service.IadminService;

public class Client {
	public static void main(String[] args) {

	Purchasedetails purchase= new Purchasedetails();
	IadminService service=new AdminServiceImp1();
	Scanner sc =new Scanner(System.in);
	System.out.println("enter Purchase id");
	int p=sc.nextInt();
	System.out.println("enter name of customer");
	String name=sc.next();
	System.out.println("enter Mailid");
	String mail=sc.next();
	System.out.println("enter Phone NUmber");
	String phn=sc.next();
	System.out.println("enter datein pattern (dd-mm-yyyy)");
	String dt=sc.next();
	DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd-MM-yyyy");
	LocalDate ed=LocalDate.parse(dt,formatter);
	System.out.println("enter Mobile code");
	int m=sc.nextInt();
	purchase.setPurchaseid(p);
	purchase.setCname(name);
	purchase.setMailid(mail);
	purchase.setPhoneno(phn);
	purchase.setPurchasedate(ed);
	purchase.setMobileid(m);
	
	try
	{
		Purchasedetails p1= service.addCdetails(purchase);
		System.out.println("purchase Detailes is uploded");
	}catch (AdminException e)
	{
		System.out.println(e.getMessage());
		
	}
	
	
	}
}
