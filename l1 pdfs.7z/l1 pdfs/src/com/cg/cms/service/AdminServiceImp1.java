package com.cg.cms.service;

import com.cg.cms.dao.AdminDaoImp1;
import com.cg.cms.dao.IadminDao;
import com.cg.cms.dto.Purchasedetails;
import com.cg.cms.exception.AdminException;

public class AdminServiceImp1 implements IadminService{
	IadminDao dao;
	public AdminServiceImp1() {
		dao=new AdminDaoImp1();
	}

	@Override
	public Purchasedetails addCdetails(Purchasedetails purchase)
			throws AdminException {
		return dao.addCdetails(purchase);
	}

}
