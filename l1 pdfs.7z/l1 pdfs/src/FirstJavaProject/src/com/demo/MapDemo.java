package com.cg.collections.demo;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class MapDemo {
	public static void main(String[] args) {
		HashMap<Integer, String> map= new HashMap<>();
		map.put(123, "Pune");
		map.put(73, "Chennai");
		map.put(243, "Mumbai");
		map.put(1784, "Mumbai");
		map.put(384, "Pune");
		map.put(622, "Mumbai");
		map.put(384, "Bangalore");
		
		String loc= map.get(73);
		System.out.println(loc);
		
		
	Set<Integer>keys=	map.keySet();
		
	for(Integer empid : keys ){
		loc= map.get(empid);
		System.out.println(empid+ " "+ loc);
		
	}		
	/*	int size= map.size();
		System.out.println(size);
   	    Set<Entry<Integer,String>>  entries=	map.entrySet();
	    Iterator<Entry<Integer,String>> itr= entries.iterator();
	     while(itr.hasNext()){
		  Entry<Integer,String> entry= itr.next();
		  System.out.println(entry.getKey()+" -> " + entry.getValue() );
		 }*/
	}
}
