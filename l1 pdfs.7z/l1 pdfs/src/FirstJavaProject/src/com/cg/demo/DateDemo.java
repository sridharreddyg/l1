package com.cg.demo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


public class DateDemo {

	public static void main(String[] args) {
		
		LocalDate date= LocalDate.now();
		System.out.println(date);
		
		DateTimeFormatter formatter = 
					DateTimeFormatter.ofPattern(" dd MMMM yy, EEEE ");
		
		String str= date.format(formatter);
		
		System.out.println(str);
	
	}
}
