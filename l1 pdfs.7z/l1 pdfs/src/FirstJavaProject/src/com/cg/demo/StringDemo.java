package com.cg.demo;

public class StringDemo {

	public static void main(String[] args) {
		String str1="Hello";
		String str2=new String( "hello");
		System.out.println(str1.hashCode());
		System.out.println(str2.hashCode());
		System.out.println(str1== str2 );
		System.out.println(str1.equals(str2));
	}
}
