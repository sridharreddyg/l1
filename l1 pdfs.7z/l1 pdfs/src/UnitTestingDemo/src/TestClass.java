import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.demo.Calculator;

public class TestClass {   

	@BeforeClass
	public static void beforeClassMathod(){
		
		System.out.println("@Beforeclass Method ...");
	}
	
	@Before
	public void init(){
		System.out.println("@before mthod ");
	}
	
	@After
	public void cleanup(){
		System.out.println("@after method ");
	}
	@AfterClass
	public static void afterClassMethod(){
		System.out.println("@AfterClass method...");
	}
	 @Test
	public void testAddMethodForValidInput(){
		 System.out.println("in 1st test method ");
		Calculator calc= new Calculator();
		int res= calc.add(10,3);
		Assert.assertEquals(13, res);
	 }
	@Test
	 public void testDivideForValidInput(){
		System.out.println("in 2nd test method ");
		 Calculator calc= new Calculator();
		 float res= calc.divide(25,10);
		 Assert.assertEquals(2.5, res, 0.001);
	 }
	@Ignore
	@Test(expected=ArithmeticException.class)
	public void testDivideForZero(){
		System.out.println("in 3rd test method..");
		 Calculator calc= new Calculator();
		 float res= calc.divide(25,0);
	}
	
	@Test
	public void testEvenOdd(){
		Calculator calc= new Calculator();
		boolean res= calc.evenOdd(6);
		Assert.assertTrue(res);
	}
	
		
	
}
