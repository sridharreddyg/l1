import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;


import org.junit.runners.Parameterized.Parameters;

import junit.framework.Assert;

import com.cg.demo.Calculator;

@RunWith(Parameterized.class)
public class TestClassDemo1 {
	private int input1,input2,output;
	public TestClassDemo1(int in1,int in2, int out ){
		input1=in1;
		input2=in2;
		output=out;
	}
	@Parameters
	public static  Collection getData(){
		Object arr[][]= {{5,2,7},{0,-4,-4},{-2,4,2},{-1,1,0}};		
		return Arrays.asList(arr);
		}
	@Test
	public void testCalcSquare(){
		Calculator calc= new Calculator();
		System.out.println("testing method for : "+ input1+ "," + input2 );
		int res= calc.add(input1,input2);
		Assert.assertEquals(output, res);
	}
}
