package com.mockdemo;

public interface B {

	public String f2(String a,String b);
}
