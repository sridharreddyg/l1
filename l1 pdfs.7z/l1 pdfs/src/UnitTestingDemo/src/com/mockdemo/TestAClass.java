package com.mockdemo;

import junit.framework.Assert;

import org.easymock.EasyMock;
import org.junit.Test;

public class TestAClass {
	@Test
	public void testf1Method(){
		
		B mock=EasyMock.createMock(B.class);
		A a1= new A();
		a1.setObj(mock);
		EasyMock.expect(mock.f2("Hello", "World")).andReturn("HelloWorld");
		EasyMock.replay(mock);
			
		int res= a1.f1("Hello", "World");
		Assert.assertEquals(10, res);
		
	}
}
