package com.mockdemo;

public class A {
	B obj;
	public B getObj() {
		return obj;
	}
	public void setObj(B obj) {
		this.obj = obj;
	}
	public int f1(String str1,String str2){
		String str= obj.f2(str1, str2);
		return str.length();
	}
}
