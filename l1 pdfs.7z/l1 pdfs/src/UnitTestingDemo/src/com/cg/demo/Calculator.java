package com.cg.demo;

public class Calculator {

	public int add(int i, int j) {
		return i+j;
	}

	public float divide(int i, int j) {
		if(j==0)
			throw new ArithmeticException();
		float res= (float)i/j;
		System.out.println(res);
		return res;
	}

	public boolean evenOdd(int i) {
		if(i%2==0)
			return true;
		else
		return false;
	}
	
	
	public int calcSquare(int num){
		return num*num;
	}
}
