import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class InsertDemo {

public static void main(String[] args) {
	
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter student code ");
	int code= sc.nextInt();
	System.out.println("Enter Name : ");
	String name= sc.next();
	System.out.println("Enter Course code : ");
	int cc= sc.nextInt();
	System.out.println("Enter address ");
	String address= sc.next();
	System.out.println("Enter Enrolled Date as : (dd-MM-yyyyy)");
	String dt= sc.next();
	DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd-MM-yyyy");
	LocalDate ed=LocalDate.parse(dt, formatter); 
	
	String sql="insert into student"
			+ " (student_code,name ,enrollDate,address,course_code)"
			+ "  values (?,?,?,?,?)";
	Connection con=DatabaseConnection.getConnection();
	try {
		PreparedStatement ps= con.prepareStatement(sql);
		ps.setInt(1, code);
		ps.setString(2, name);
		Date sqlDate= Date.valueOf(ed);
		ps.setDate(3,sqlDate );
		ps.setString(4, address);
		ps.setInt(5, cc);
		int row=ps.executeUpdate();
		System.out.println(row+ " inserted.");
	
	}catch (SQLException e) {
		if(e.getErrorCode()==1){
			System.out.println("Student code already exists!!!");
		}
		else if(e.getErrorCode()==2291){
			System.out.println("Invalid course code !!!!");
		}
		else
			System.out.println(e.getMessage());
	}


}	
	
}
