import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class UpdateDemo {

	public static void main(String[] args) {
		String sql="update course set duration =?  where course_code= ?";
		int duration;
		int code ;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter course code ");
		code= sc.nextInt();
		System.out.println("Enter duration ");
		duration= sc.nextInt();
		Connection con= DatabaseConnection.getConnection();
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setInt(1, duration);
			ps.setInt(2, code);
			int row= ps.executeUpdate();
			System.out.println(row+" updated ");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

	}
}
